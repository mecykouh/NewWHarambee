
$(function() {
  $('[data-bs-toggle="datepicker"]').datepicker({
	autoHide: true,
	zIndex: 999998,
  });
});
