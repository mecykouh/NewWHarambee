$(function() {
    $("#mobile-number").intlTelInput();
});

