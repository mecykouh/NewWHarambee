<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'libs/App.php';?>
<?php 
	
	$app = new App();
	//get all fundraisers
	if(isset($_SESSION['id'])){
	    $id = $_SESSION['id'];
    	$query = "SELECT * FROM tblContributions WHERE contributionAdminId = $id";
    	$allFundraisers = $app->selectAll($query);
	}else{
	    header("location: index.php");
	}
	

?>
<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
        
        <!-- TITLE -->
        <title> W-Harambee Dashboard </title>

        <!-- FAVICON -->
        <link rel="icon" href="public/img/brand/favicon.ico">

        
		<!-- BOOTSTRAP CSS -->
		<link  id="style" href="public/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		<!-- ICONS CSS -->
		<link href="public/plugins/web-fonts/icons.css" rel="stylesheet">
		<link href="public/plugins/web-fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
		<link href="public/plugins/web-fonts/plugin.css" rel="stylesheet">

		<!-- STYLE CSS -->
		<link href="public/css/style.css" rel="stylesheet">
		<link href="public/css/plugins.css" rel="stylesheet">

        <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
        

    </head>

    <body class="ltr main-body leftmenu">

       
        <!-- PAGE -->
        <div class="page">

         <!-- HEADER -->
                    
			<div class="main-header side-header sticky">
				<div class="main-container container-fluid">
					<div class="main-header-left">
						<a class="main-header-menu-icon" href="javascript:void(0);" id="mainSidebarToggle"><span></span></a>
						<div class="hor-logo">
							<a class="main-logo" href="index.html">
								<img src="public/img/logo.png" class="header-brand-img desktop-logo" alt="logo">
								<img src="public/img/logo-light.png" class="header-brand-img desktop-logo-dark"
									alt="logo">
							</a>
						</div>
					</div>
					<div class="main-header-center">
						<div class="responsive-logo">
							<a href="index.php"><img src="public/img/logo.png" class="mobile-logo" alt="logo"></a>
							<a href="index.php"><img src="public/img/logo.png" class="mobile-logo-dark"
									alt="logo"></a>
						</div>
						<div class="input-group">
							
							<input type="search" class="form-control rounded-0" placeholder="Search for anything...">
							<button class="btn search-btn"><i class="fe fe-search"></i></button>
						</div>
					</div>
					<div class="main-header-right">
						<button class="navbar-toggler navresponsive-toggler" type="button" data-bs-toggle="collapse"
							data-bs-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4"
							aria-expanded="false" aria-label="Toggle navigation">
							<i class="fe fe-more-vertical header-icons navbar-toggler-icon"></i>
						</button><!-- Navresponsive closed -->
						<div
							class="navbar navbar-expand-lg  nav nav-item  navbar-nav-right responsive-navbar navbar-dark  ">
							<div class="collapse navbar-collapse" id="navbarSupportedContent-4">
								<div class="d-flex order-lg-2 ms-auto">
								
									<!-- Theme-Layout -->
									<div class="dropdown d-flex main-header-theme">
										<a class="nav-link icon layout-setting">
											<span class="dark-layout">
												<i class="fe fe-sun header-icons"></i>
											</span>
											<span class="light-layout">
												<i class="fe fe-moon header-icons"></i>
											</span>
										</a>
									</div>
									<!-- Theme-Layout -->
									
									<!-- Full screen -->
									<div class="dropdown ">
										<a class="nav-link icon full-screen-link">
											<i class="fe fe-maximize fullscreen-button fullscreen header-icons"></i>
											<i class="fe fe-minimize fullscreen-button exit-fullscreen header-icons"></i>
										</a>
									</div>
									<!-- Full screen -->
									<!-- Notification -->
									<div class="dropdown main-header-notification">
										<a class="nav-link icon" href="javascript:void(0);">
											<i class="fe fe-bell header-icons"></i>
											<span class="badge bg-danger nav-link-badge">1</span>
										</a>
										<div class="dropdown-menu">
											<div class="header-navheading">
												<p class="main-notification-text">You have 1 unread notification<span
														class="badge bg-pill bg-primary ms-3">View all</span></p>
											</div>
											<div class="main-notification-list">
												<div class="media new">
													
													<div class="media-body">
														<p>You have a <strong>Fundraiser</strong> that is now inactive</p>
														<span>Oct 15 12:32pm</span>
													</div>
												</div>
											
											</div>
											<div class="dropdown-footer">
												<a href="#">View All Notifications</a>
											</div>
										</div>
									</div>
									<!-- Notification -->
									
									<!-- Profile -->
									<div class="dropdown main-profile-menu">
										<a class="d-flex" href="javascript:void(0);">
											<span class="main-img-user"><img alt="avatar"
													src="public/img/users/1.jpg"></span>
										</a>
										<div class="dropdown-menu">
											<div class="header-navheading">
												<h6 class="main-notification-title">Full Name</h6>
												
											</div>
											<a class="dropdown-item border-top" href="#">
												<i class="fe fe-user"></i> My Profile
											</a>
											
											<a class="dropdown-item" href="profile.html">
												<i class="fe fe-settings"></i> Account Settings
											</a>
											<a class="dropdown-item" href="#">
												<i class="fe fe-settings"></i> Support
											</a>
										
											<a class="dropdown-item" href="signin.html">
												<i class="fe fe-power"></i> Sign Out
											</a>
										</div>
									</div>
									<!-- Profile -->
									
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
            <!-- END HEADER -->

            <!-- SIDEBAR -->
            
			<div class="sticky">
				<div class="main-menu main-sidebar main-sidebar-sticky side-menu">
					<div class="main-sidebar-header main-container-1 active">
						<div class="sidemenu-logo">
                        <a class="main-logo" href="index.php">
								<img src="public/img/logo.png" class="header-brand-img desktop-logo" alt="logo">
								<img src="public/img/logo.png" class="header-brand-img icon-logo" alt="logo">
								<img src="public/img/logo.png" class="header-brand-img desktop-logo theme-logo" alt="logo">
								<img src="public/img/logo.png" class="header-brand-img icon-logo theme-logo" alt="logo">
							</a>
						
						</div>
						<div class="main-sidebar-body main-body-1">
							<div class="slide-left disabled" id="slide-left"><i class="fe fe-chevron-left"></i></div>
							<ul class="menu-nav nav">
								<li class="nav-header"><span class="nav-label">Dashboard</span></li>
                               
						
								<li class="nav-item">
									<a class="nav-link" href="index.php">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i class="ti-home sidemenu-icon menu-icon"></i>
										<span class="sidemenu-label">Dashboard</span>
									</a>
								</li>
								<li class="nav-item">
									<a class="nav-link with-sub" href="javascript:void(0)">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i  class="typcn typcn-gift sidemenu-icon menu-icon "></i>
										<span class="sidemenu-label">Fundraisers</span>
										<i class="angle fe fe-chevron-right"></i>
									</a>
									<ul class="nav-sub">
										<li class="side-menu-label1"><a href="javascript:;">All Fundraisers</a></li>
										<li class="nav-sub-item"> <a class="nav-sub-link" href="create_fundraiser.php">Create Fundraiser</a></li>
                                        <li class="nav-sub-item"> <a class="nav-sub-link" href="all_fundraisers.php">All Fundraisers</a></li>
										
									</ul>
								</li>
                                <li class="nav-item">
									<a class="nav-link with-sub" href="javascript:void(0)">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i  class="typcn typcn-cog-outline sidemenu-icon menu-icon "></i>
										<span class="sidemenu-label">Settings</span>
										<i class="angle fe fe-chevron-right"></i>
									</a>
									<ul class="nav-sub">
										<li class="side-menu-label1"><a href="javascript:;">Settings</a></li>
										<li class="nav-sub-item"> <a class="nav-sub-link" href="#">Edit Profile</a></li>
                                        <li class="nav-sub-item"> <a class="nav-sub-link" href="#">Security</a></li>
										
									</ul>
								</li>
                                <li class="nav-item">
									<a class="nav-link" href="logout.php">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i class="typcn typcn-lock-closed sidemenu-icon menu-icon"></i>
										<span class="sidemenu-label">Logout</span>
									</a>
								</li>
                                
								
								
							</ul>
							<div class="slide-right" id="slide-right"><i class="fe fe-chevron-right"></i></div>
						</div>
					</div>
				</div>
			</div>
            <!-- END SIDEBAR -->

            <!-- MAIN-CONTENT -->
            <div class="main-content side-content pt-0">
                <div class="main-container container-fluid">
                    <div class="inner-body">

                        
						<!-- Page Header -->
						<div class="page-header">
							<div>
								<h2 class="main-content-title tx-24 mg-b-5">All Fundraiser</h2>
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="javascript:void(0);">Fundraisers</a></li>
									<li class="breadcrumb-item active" aria-current="page">New Fundraiser</li>
								</ol>
							</div>
							
						</div>
						<!-- End Page Header -->

					<!-- Row -->
                    <div class="row row-sm">
							<div class="col-lg-12">
								<div class="card custom-card overflow-hidden">
									<div class="card-body">
										<div>
											<h6 class="main-content-label mb-1">All My Fundraisings</h6>
										</div>
										<div class="table-responsive">
											<table id="exportexample" class="table table-bordered border-t0 key-buttons text-nowrap w-100" >
												<thead>
													<tr>
                                                    <th>Fundraiser Name</th>
								<th>Till No</th>
								<th>Total Amount</th>
								<th>Date Created</th>
                                <th>Action</th>
													</tr>
												</thead>
												<tbody>
													
                                                    <?php 

if($allFundraisers !== false):
    foreach($allFundraisers as $fundraiser):
        
        echo "<tr>";
        echo '<td>';
        echo '<a href="fundraiser.php?id=' . $fundraiser->id  . '">';
        echo $fundraiser->contributionName;
        echo '</td>';
        echo "<td>" . $fundraiser->contributionTillNo . "</td>";
        echo "<td>" . number_format($fundraiser->contributionTotalAmount) . "</td>";
        echo "<td>" . $fundraiser->dateCreated . "</td>";
        // echo '<td><span class="status completed">' . $contributionName . "</span></td>";
        echo '<td>';
        echo '<a href="edit-fundraiser.php?id=' . $fundraiser->id . '">';
        echo '<i class="bx bx-edit"> Edit</i> </a>';
        echo '</td>';
        echo "</tr>";
        
    endforeach;
endif;


?>
													
													
													
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Row -->


                    </div>
                </div>
            </div>
            <!-- END MAIN-CONTENT -->

         
            <!-- FOOTER -->
            
            <div class="main-footer text-center">
				<div class="container">
					<div class="row row-sm">
						<div class="col-md-12">
							<span>Copyright © <?php echo date("Y");?> W-Harambee. All rights reserved.</span>
						</div>
					</div>
				</div>
			</div>
            <!-- END FOOTER -->

        </div>
        <!-- END PAGE -->

        <!-- SCRIPTS -->
        		
		<!-- BACK TO TOP -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- JQUERY JS -->
		<script src="public/plugins/jquery/jquery.min.js"></script>

		<!-- BOOTSTRAP JS -->
		<script src="public/plugins/bootstrap/js/popper.min.js"></script>
		<script src="public/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!-- PERFECT SCROLLBAR JS -->
		<script src="public/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- SIDEMENU JS -->
		<script src="public/plugins/sidemenu/sidemenu.js" id="leftmenu"></script>

		<!-- SIDEBAR JS -->
		<script src="public/plugins/sidebar/sidebar.js"></script>

		<!-- SELECT2 JS -->
		<script src="public/plugins/select2/js/select2.min.js"></script>
		<script src="public/js/select2.js"></script>
        
		<!-- INTERNAL CHART.BUNDLE JS -->
		<script src="public/plugins/chart.js/Chart.bundle.min.js"></script>

		<!-- INTERNAL BLOG POST JS -->
		<script src="public/js/blog-post.js"></script>

		<!-- INTERNAL QUILL JS -->
		<script src="public/plugins/quill/quill.min.js"></script>

		<!--INTERNAL FANCY UPLOADER JS -->
		<script src="public/plugins/fancyuploder/jquery.ui.widget.js"></script>
		<script src="public/plugins/fancyuploder/jquery.fileupload.js"></script>
		<script src="public/plugins/fancyuploder/jquery.iframe-transport.js"></script>
		<script src="public/plugins/fancyuploder/jquery.fancy-fileupload.js"></script>
		<script src="public/plugins/fancyuploder/fancy-uploader.js"></script>

        
        <!-- STICKY JS -->
		<script src="public/js/sticky.js"></script>

        <!-- COLOR THEME JS -->
        <script src="public/js/themeColors.js"></script>

        <!-- CUSTOM JS -->
        <script src="public/js/custom.js"></script>

        <!-- SWITCHER JS -->
        <script src="public/switcher/js/switcher.js"></script>

        <!-- INTERNAL DATA TABLE JS -->
		<script src="public/plugins/datatable/js/jquery.dataTables.min.js"></script>
		<script src="public/plugins/datatable/js/dataTables.bootstrap5.js"></script>
		<script src="public/plugins/datatable/js/dataTables.buttons.min.js"></script>
		<script src="public/plugins/datatable/js/buttons.bootstrap5.min.js"></script>
		<script src="public/plugins/datatable/js/jszip.min.js"></script>
		<script src="public/plugins/datatable/pdfmake/pdfmake.min.js"></script>
		<script src="public/plugins/datatable/pdfmake/vfs_fonts.js"></script>
		<script src="public/plugins/datatable/js/buttons.html5.min.js"></script>
		<script src="public/plugins/datatable/js/buttons.print.min.js"></script>
		<script src="public/plugins/datatable/js/buttons.colVis.min.js"></script>
		<script src="public/plugins/datatable/dataTables.responsive.min.js"></script>
		<script src="public/plugins/datatable/responsive.bootstrap5.min.js"></script>
		<script src="public/js/table-data.js"></script>
		<script src="public/js/select2.js"></script>


        <!-- END SCRIPTS -->

    
    
</html>
