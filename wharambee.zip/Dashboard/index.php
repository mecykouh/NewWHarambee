<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'libs/App.php';?>
<?php 
	
	$app = new App();
	//get all fundraisers
	if(isset($_SESSION['id'])){
	    $id = $_SESSION['id'];
    	$query = "SELECT * FROM tblcontributions WHERE contributionAdminId = $id";
    	$allFundraisers = $app->selectAll($query);
	}else{
	    header("location: ../index.php");
	}
	

?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
       
        <!-- TITLE -->
        <title> W-Harambee Dashboard </title>

        <!-- FAVICON -->
        <link rel="icon" href="public/img/brand/favicon.ico">

        
		<!-- BOOTSTRAP CSS -->
		<link  id="style" href="public/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		<!-- ICONS CSS -->
		<link href="public/plugins/web-fonts/icons.css" rel="stylesheet">
		<link href="public/plugins/web-fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
		<link href="public/plugins/web-fonts/plugin.css" rel="stylesheet">

		<!-- STYLE CSS -->
		<link href="public/css/style.css" rel="stylesheet">
		<link href="public/css/plugins.css" rel="stylesheet">        

    </head>

    <body class="ltr main-body leftmenu">

        <!-- PAGE -->
        <div class="page">

            <!-- HEADER -->
                    
			<div class="main-header side-header sticky">
				<div class="main-container container-fluid">
					<div class="main-header-left">
						<a class="main-header-menu-icon" href="javascript:void(0);" id="mainSidebarToggle"><span></span></a>
						<div class="hor-logo">
							<a class="main-logo" href="index.html">
								<img src="public/img/logo.png" class="header-brand-img desktop-logo" alt="logo">
								<img src="public/img/logo-light.png" class="header-brand-img desktop-logo-dark"
									alt="logo">
							</a>
						</div>
					</div>
					<div class="main-header-center">
						<div class="responsive-logo">
							<a href="index.php"><img src="public/img/logo.png" class="mobile-logo" alt="logo"></a>
							<a href="index.php"><img src="public/img/logo.png" class="mobile-logo-dark"
									alt="logo"></a>
						</div>
						<div class="input-group">
							
							<input type="search" class="form-control rounded-0" placeholder="Search for anything...">
							<button class="btn search-btn"><i class="fe fe-search"></i></button>
						</div>
					</div>
					<div class="main-header-right">
						<button class="navbar-toggler navresponsive-toggler" type="button" data-bs-toggle="collapse"
							data-bs-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4"
							aria-expanded="false" aria-label="Toggle navigation">
							<i class="fe fe-more-vertical header-icons navbar-toggler-icon"></i>
						</button><!-- Navresponsive closed -->
						<div
							class="navbar navbar-expand-lg  nav nav-item  navbar-nav-right responsive-navbar navbar-dark  ">
							<div class="collapse navbar-collapse" id="navbarSupportedContent-4">
								<div class="d-flex order-lg-2 ms-auto">
								
									<!-- Theme-Layout -->
									<div class="dropdown d-flex main-header-theme">
										<a class="nav-link icon layout-setting">
											<span class="dark-layout">
												<i class="fe fe-sun header-icons"></i>
											</span>
											<span class="light-layout">
												<i class="fe fe-moon header-icons"></i>
											</span>
										</a>
									</div>
									<!-- Theme-Layout -->
									
									<!-- Full screen -->
									<div class="dropdown ">
										<a class="nav-link icon full-screen-link">
											<i class="fe fe-maximize fullscreen-button fullscreen header-icons"></i>
											<i class="fe fe-minimize fullscreen-button exit-fullscreen header-icons"></i>
										</a>
									</div>
									<!-- Full screen -->
									<!-- Notification -->
									<div class="dropdown main-header-notification">
										<a class="nav-link icon" href="javascript:void(0);">
											<i class="fe fe-bell header-icons"></i>
											<span class="badge bg-danger nav-link-badge">1</span>
										</a>
										<div class="dropdown-menu">
											<div class="header-navheading">
												<p class="main-notification-text">You have 1 unread notification<span
														class="badge bg-pill bg-primary ms-3">View all</span></p>
											</div>
											<div class="main-notification-list">
												<div class="media new">
													
													<div class="media-body">
														<p>You have a <strong>Fundraiser</strong> that is now inactive</p>
														<span>Oct 15 12:32pm</span>
													</div>
												</div>
											
											</div>
											<div class="dropdown-footer">
												<a href="#">View All Notifications</a>
											</div>
										</div>
									</div>
									<!-- Notification -->
									
									<!-- Profile -->
									<div class="dropdown main-profile-menu">
										<a class="d-flex" href="javascript:void(0);">
											<span class="main-img-user"><img alt="avatar"
													src="public/img/users/1.jpg"></span>
										</a>
										<div class="dropdown-menu">
											<div class="header-navheading">
												<h6 class="main-notification-title">Full Name</h6>
												
											</div>
											<a class="dropdown-item border-top" href="#">
												<i class="fe fe-user"></i> My Profile
											</a>
											
											<a class="dropdown-item" href="profile.html">
												<i class="fe fe-settings"></i> Account Settings
											</a>
											<a class="dropdown-item" href="#">
												<i class="fe fe-settings"></i> Support
											</a>
										
											<a class="dropdown-item" href="signin.html">
												<i class="fe fe-power"></i> Sign Out
											</a>
										</div>
									</div>
									<!-- Profile -->
									
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
            <!-- END HEADER -->

            <!-- SIDEBAR -->
            
			<div class="sticky">
				<div class="main-menu main-sidebar main-sidebar-sticky side-menu">
					<div class="main-sidebar-header main-container-1 active">
						<div class="sidemenu-logo">
							<a class="main-logo" href="index.php">
								<img src="public/img/logo.png" class="header-brand-img desktop-logo" alt="logo">
								<img src="public/img/logo.png" class="header-brand-img icon-logo" alt="logo">
								<img src="public/img/logo.png" class="header-brand-img desktop-logo theme-logo" alt="logo">
								<img src="public/img/logo.png" class="header-brand-img icon-logo theme-logo" alt="logo">
							</a>
						</div>
						<div class="main-sidebar-body main-body-1">
							<div class="slide-left disabled" id="slide-left"><i class="fe fe-chevron-left"></i></div>
							
                            <ul class="menu-nav nav">
								<li class="nav-header"><span class="nav-label">Dashboard</span></li>
                               
						
								<li class="nav-item">
									<a class="nav-link" href="index.php">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i class="ti-home sidemenu-icon menu-icon"></i>
										<span class="sidemenu-label">Dashboard</span>
									</a>
								</li>
								<li class="nav-item">
									<a class="nav-link with-sub" href="javascript:void(0)">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i  class="typcn typcn-gift sidemenu-icon menu-icon "></i>
										<span class="sidemenu-label">Fundraisers</span>
										<i class="angle fe fe-chevron-right"></i>
									</a>
									<ul class="nav-sub">
										<li class="side-menu-label1"><a href="javascript:;">Create Fundraiser</a></li>
										<li class="nav-sub-item"> <a class="nav-sub-link" href="create_fundraiser.php">Create Fundraiser</a></li>
                                        <li class="nav-sub-item"> <a class="nav-sub-link" href="all_fundraisers.php">All Fundraisers</a></li>
										
									</ul>
								</li>
                                <li class="nav-item">
									<a class="nav-link with-sub" href="javascript:void(0)">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i  class="typcn typcn-cog-outline sidemenu-icon menu-icon "></i>
										<span class="sidemenu-label">Settings</span>
										<i class="angle fe fe-chevron-right"></i>
									</a>
									<ul class="nav-sub">
										<li class="side-menu-label1"><a href="javascript:;">Settings</a></li>
										<li class="nav-sub-item"> <a class="nav-sub-link" href="#">Edit Profile</a></li>
                                        <li class="nav-sub-item"> <a class="nav-sub-link" href="#">Security</a></li>
										
									</ul>
								</li>
                                <li class="nav-item">
									<a class="nav-link" href="logout.php">
										<span class="shape1"></span>
										<span class="shape2"></span>
										<i class="typcn typcn-lock-closed sidemenu-icon menu-icon"></i>
										<span class="sidemenu-label">Logout</span>
									</a>
								</li>
                              
								
							</ul>
						
							<div class="slide-right" id="slide-right"><i class="fe fe-chevron-right"></i></div>
						</div>
					</div>
				</div>
			</div>
            <!-- END SIDEBAR -->

            <!-- MAIN-CONTENT -->
            <div class="main-content side-content pt-0">
                <div class="main-container container-fluid">
                    <div class="inner-body">

                        
						<!-- Page Header -->
						<div class="page-header">
							<div>
								<h2 class="main-content-title tx-24 mg-b-5">Welcome To W-Harambee</h2>
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
								</ol>
							</div>
							<div class="d-flex">
								<div class="justify-content-center">
								<a href="create_fundraiser.php">
									<button type="button" class="btn btn-primary my-2 btn-icon-text">
										<i class="fe fe-download-cloud me-2"></i> Create A New Fundraiser
									</button>
                                </a>
								</div>
							</div>
						</div>
						<!-- End Page Header -->

						<!--Row-->
						<div class="row row-sm">
							<div class="col-sm-12 col-lg-12 col-xl-8">

								<!--Row-->
								<div class="row row-sm  mt-lg-4">
									<div class="col-sm-12 col-lg-12 col-xl-12">
										<div class="card bg-primary custom-card card-box">
											<div class="card-body p-4">
												<div class="row align-items-center">
													<div class="offset-xl-0 offset-sm-6 col-xl-8 col-sm-6 col-12  ">
														<h4 class="d-flex  mb-3">
															<span class="font-weight-bold text-white ">Hello Victor</span>
														</h4>
														<p class="tx-white-7 mb-1">You have one fundraiser to complete <b class="text-warning">57%</b> from your total fundraisers. Finish it today
													</div>
												
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--Row -->

								<!--Row-->
								<div class="row row-sm">
									<div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
										<div class="card custom-card">
											<div class="card-body">
												<div class="card-item">
													<div class="card-item-icon card-icon">
														<svg class="text-primary" xmlns="http://www.w3.org/2000/svg"
															enable-background="new 0 0 24 24" height="24"
															viewBox="0 0 24 24" width="24">
															<g>
																<rect height="14" opacity=".3" width="14" x="5" y="5" />
																<g>
																	<rect fill="none" height="24" width="24" />
																	<g>
																		<path
																			d="M19,3H5C3.9,3,3,3.9,3,5v14c0,1.1,0.9,2,2,2h14c1.1,0,2-0.9,2-2V5C21,3.9,20.1,3,19,3z M19,19H5V5h14V19z" />
																		<rect height="5" width="2" x="7" y="12" />
																		<rect height="10" width="2" x="15" y="7" />
																		<rect height="3" width="2" x="11" y="14" />
																		<rect height="2" width="2" x="11" y="10" />
																	</g>
																</g>
															</g>
														</svg>
													</div>
													<div class="card-item-title mb-2">
														<label class="main-content-label tx-13 font-weight-bold mb-1">Fundraisers</label>
														<span class="d-block tx-12 mb-0 text-muted">All Fundraisers To Date</span>
													</div>
													<div class="card-item-body">
														<div class="card-item-stat">
															<h4 class="font-weight-bold"> <?php
							//get number of fundraisers
							$arrayRows = (array)$allFundraisers;
							$totalFundraisers = count($arrayRows);
							
							echo  $totalFundraisers;
					    ?></h4>
															
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									
									<div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
										<div class="card custom-card">
											<div class="card-body">
												<div class="card-item">
													<div class="card-item-icon card-icon">
														<svg class="text-primary" xmlns="http://www.w3.org/2000/svg"
															height="24" viewBox="0 0 24 24" width="24">
															<path d="M0 0h24v24H0V0z" fill="none" />
															<path
																d="M12 4c-4.41 0-8 3.59-8 8s3.59 8 8 8 8-3.59 8-8-3.59-8-8-8zm1.23 13.33V19H10.9v-1.69c-1.5-.31-2.77-1.28-2.86-2.97h1.71c.09.92.72 1.64 2.32 1.64 1.71 0 2.1-.86 2.1-1.39 0-.73-.39-1.41-2.34-1.87-2.17-.53-3.66-1.42-3.66-3.21 0-1.51 1.22-2.48 2.72-2.81V5h2.34v1.71c1.63.39 2.44 1.63 2.49 2.97h-1.71c-.04-.97-.56-1.64-1.94-1.64-1.31 0-2.1.59-2.1 1.43 0 .73.57 1.22 2.34 1.67 1.77.46 3.66 1.22 3.66 3.42-.01 1.6-1.21 2.48-2.74 2.77z"
																opacity=".3" />
															<path
																d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.31-8.86c-1.77-.45-2.34-.94-2.34-1.67 0-.84.79-1.43 2.1-1.43 1.38 0 1.9.66 1.94 1.64h1.71c-.05-1.34-.87-2.57-2.49-2.97V5H10.9v1.69c-1.51.32-2.72 1.3-2.72 2.81 0 1.79 1.49 2.69 3.66 3.21 1.95.46 2.34 1.15 2.34 1.87 0 .53-.39 1.39-2.1 1.39-1.6 0-2.23-.72-2.32-1.64H8.04c.1 1.7 1.36 2.66 2.86 2.97V19h2.34v-1.67c1.52-.29 2.72-1.16 2.73-2.77-.01-2.2-1.9-2.96-3.66-3.42z" />
														</svg>
													</div>
													<div class="card-item-title  mb-2">
														<label class="main-content-label tx-13 font-weight-bold mb-1">Total
															Amount Raised</label>
                                                            <span class="d-block tx-12 mb-0 text-muted">Total Money Contributed To Date</span>
																											</div>
													<div class="card-item-body">
														<div class="card-item-stat">
															<h4 class="font-weight-bold">Ksh. <?php



					    //get total amount of all fundraisers
                        $totalAmountRaised = 0;
						if($allFundraisers !== false):
							foreach($allFundraisers as $fundraiser):
								$totalAmountRaised += $fundraiser->contributionTotalAmount;
							endforeach;
							echo number_format($totalAmountRaised);
						else:
							echo "0";
						endif;
                        
					    ?></h4>
															
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--End row-->
                        					
							</div><!-- col end -->

                             <!-- Recent Transactions --->

							<div class="col-sm-12 col-lg-12 col-xl-4 mt-xl-4">
								<div class="card custom-card card-dashboard-calendar pb-0">
									<label class="main-content-label mb-2 pt-1">Recent Transactions</label>
									
									<table class="table table-hover m-b-0 transcations mt-2">
										<tbody>
											
											<tr>
												
												<td>
													<div class="d-flex align-middle ms-3">
														<div class="d-inline-block">
															<h6 class="mb-1">Full Name</h6>
															<p class="mb-0 tx-13 text-muted">0712 ****78</p>
														</div>
													</div>
												</td>
												<td class="text-end">
													<div class="d-inline-block">
														<h6 class="mb-2 tx-15 font-weight-semibold">Ksh. 4,000
														</h6>
														<p class="mb-0 tx-11 text-muted">23 August 2023</p>
													</div>
												</td>
											</tr>
											
										</tbody>
									</table>
								</div>
								
								
							</div><!-- col end -->
						</div>
						<!-- Row end -->


                    </div>
                </div>
            </div>
            <!-- END MAIN-CONTENT -->

          
               <!-- FOOTER -->
            
               <div class="main-footer text-center">
				<div class="container">
					<div class="row row-sm">
						<div class="col-md-12">
							<span>Copyright © <?php echo date("Y");?> W-Harambee. All rights reserved.</span>
						</div>
					</div>
				</div>
			</div>
            <!-- END FOOTER -->


        </div>
        <!-- END PAGE -->

        <!-- SCRIPTS -->
        		
		<!-- BACK TO TOP -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- JQUERY JS -->
		<script src="public/plugins/jquery/jquery.min.js"></script>

		<!-- BOOTSTRAP JS -->
		<script src="public/plugins/bootstrap/js/popper.min.js"></script>
		<script src="public/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!-- PERFECT SCROLLBAR JS -->
		<script src="public/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- SIDEMENU JS -->
		<script src="public/plugins/sidemenu/sidemenu.js" id="leftmenu"></script>

		<!-- SIDEBAR JS -->
		<script src="public/plugins/sidebar/sidebar.js"></script>

		<!-- SELECT2 JS -->
		<script src="public/plugins/select2/js/select2.min.js"></script>
		<script src="public/js/select2.js"></script>
        
		<!-- Internal Chart.Bundle js-->
		<script src="public/plugins/chart.js/Chart.bundle.min.js"></script>

		<!-- Peity js-->
		<script src="public/plugins/peity/jquery.peity.min.js"></script>

		<!-- Internal Morris js -->
		<script src="public/plugins/raphael/raphael.min.js"></script>
		<script src="public/plugins/morris.js/morris.min.js"></script>

		<!-- Circle Progress js-->
		<script src="public/plugins/circle-progress/circle-progress.min.js"></script>
		<script src="public/js/chart-circle.js"></script>

		<!-- Internal Dashboard js-->
		<script src="public/js/index.js"></script>
        
        <!-- STICKY JS -->
		<script src="public/js/sticky.js"></script>

        <!-- COLOR THEME JS -->
        <script src="public/js/themeColors.js"></script>

        <!-- CUSTOM JS -->
        <script src="public/js/custom.js"></script>

        <!-- SWITCHER JS -->
        <script src="public/switcher/js/switcher.js"></script>

        <!-- END SCRIPTS -->

    </body>

</html>
