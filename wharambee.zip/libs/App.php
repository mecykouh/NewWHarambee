<?php require_once "config.php"; 
session_start();?>
<?php

define("APPURL", "http://localhost/wharambee");

    class App{

        public $host = HOST;
        public $user = USER;
        public $password = PASS;
        public $dbname = DBNAME;
        
        //MPESA credentials
        public $consumerKey = CONSUMER_KEY;
        public $consumerSecret = CONSUMER_SECRET;
        public $passkey = PASSKEY;
        
        //MAYTAPI Credentials
        public $product_id = PRODUCT_ID;
        public $phone_id = PHONE_ID;
        public $maytapi_token = MAYTAPI_TOKEN;

        public $link;

        //create constructor
        public function __construct(){
            $this->connect();
        }

        //db connection
        public function connect(){
            
            $this->link = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->dbname . "" , $this->user, $this->password);
            if($this->link){
                // echo "connection successful";
            }else{
                echo "connection failed";
            }
        }
        
        

        //select all query method
        public function selectAll($query){

            $rows = $this->link->query($query);
            $rows->execute();

            //fetch all rows into an object
            $allRows = $rows->fetchAll(PDO::FETCH_OBJ);
            return $allRows;
            // if($allRows){
            //     return $allRows;
            // }else{
            //     return false;
            // }

        }

        //select one row query method
        public function selectOne($query){

            $row = $this->link->query($query);
            $row->execute();

            //fetch single row into an object
            $singleRow = $row->fetch(PDO::FETCH_OBJ);

            if($singleRow){
                return $singleRow;
            }else{
                return false;
            }

        }

        //sql insert
        public function insert($query, $array, $path){

            if($this->validate($array) == "empty"){
                echo "<script>alert('some elements in the array are empty')</script>";
            }else{

                $insert_record = $this->link->prepare($query);
                $insert_record->execute($array);
                
                //check if path is empty
                if(!empty($path)){
                    //go to the location path set
                    echo "<script>window.location.href='" . $path . "'</script>";
                }

            }

        }

        //sql update function
        public function update($query, $array, $path){

            if($this->validate($array) == "empty"){
                echo "<script>alert('some elements in the array are empty')</script>";
            }else{

                $update_record = $this->link->prepare($query);
                $update_record->execute($array);

                //go to the location path set
                echo "<script>window.location.href='" . APPURL . "/" .$path . "'</script>";

            }

        }

        //sql delete function
        public function delete($query, $path){

            $delete_record = $this->link->query($query);
            $delete_record->execute();

            //go to the location path set
            header("location: " . $path);

        }

        //function to validate if array has some empty elements
        public function validate($array){

            if(in_array("", $array)){
                echo "empty";
            }

        }

        //register user function
        public function register($query, $data, $path){

            if($this->validate($data) == "empty"){
                echo "<script>alert('some fields are empty')</script>";
            }else{

                $register_user = $this->link->prepare($query);
                $register_user->execute($data);

                //go to the location path set
                echo "<script>window.location.href='" . APPURL . "/" .$path . "'</script>";

            }

        }

        //login user function
        public function login($query, $data, $path){

            // verify email exists in DB
            $login_user = $this->link->query($query);
            $login_user->execute();

            //fetch results
            $fetch = $login_user->fetch(PDO::FETCH_ASSOC);

            // verify password sent and the password hash in the DB using php native method
            if(password_verify($data['password'], $fetch['password'])){

                // password is verified
                // start session variables
                
                $_SESSION['id'] = $fetch['id'];
                $_SESSION['email'] = $fetch['emailAddress'];
                $_SESSION['phoneNumber'] = $fetch['phoneNumber'];

                echo "<script>window.location.href='" . APPURL . "/" .$path . "'</script>";
                

            }
        }

        //start session
        public function startingSession(){
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            };
        }

        //validate sessions
        public function validateSession($path){
            if(isset($_SESSION['id'])){
                echo "<script>window.location.href='" . APPURL . "/" .$path . "'</script>";
            }
        }
        
        //get whatsgroup jid from group link
        function whatsappGroupLinkExist($whatsappGroupLink){
            
            //get all whatsapp group jid
            $curl = curl_init();
        
            curl_setopt_array($curl, array(
              CURLOPT_URL => 'https://api.maytapi.com/api/' . $this->product_id . '/' . $this->phone_id . '/getGroups?invite=true', //MaytApi Product Id + Phone Id
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'GET',
              CURLOPT_HTTPHEADER => array(
                'accept: application/json',
                'x-maytapi-key: ' . $this->maytapi_token //MaytApi Token
              ),
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            $resp;
            
            curl_close($curl);
            
            //loop through groups
            $response_array = json_decode($response, true);
            $whatsappGroupJID = "";
            //check if data exists in json
            if(isset($response_array['data'])){
                
                $data = $response_array['data'];
                
                foreach($data as $nestedArray) {
                    
                    if($whatsappGroupLink == $nestedArray['invite']){
                        
                        $whatsappGroupJID = explode("@", $nestedArray['id'])[0];
                        $resp = [
                            "error" => false,
                            "whatsappGroupJID" => $whatsappGroupJID
                        ];
                        
                        
                    }
                }
                
            }else{
                //API has problems
                $resp = [
                    "error" => true,
                    "errorMessage" => json_encode($response_array)
                ];
                
                
            }
            
            if(empty($whatsappGroupJID)){
                //number not added to whatsapp group
                $resp = [
                    "error" => true,
                    "errorMessage" => "Add W-Harambee to your whatsapp group and make us an admin."
                ];
            }
            
                
            return json_encode($resp);
            
            
        }

        
    }

?>