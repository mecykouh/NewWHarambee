<?php

    define("HOST", "localhost");
    define("DBNAME", "dkhjorxm_whatsapp_bot");
    define("USER", "root");
    define("PASS", "");
    
    // Mpesa credentials
    define("CONSUMER_KEY", "");
    define("CONSUMER_SECRET", "");
    define("PASSKEY", "");
    
    //MaytApi credentials
    define("PRODUCT_ID", "");
    define("PHONE_ID", "");
    define("MAYTAPI_TOKEN", "");
